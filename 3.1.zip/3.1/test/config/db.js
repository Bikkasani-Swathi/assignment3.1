module.exports = {
    url : 'mongodb://localhost/reader_test'
}